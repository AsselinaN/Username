// let listDiv = $("#list")
// let data = [
//     {
//         name: "Asselina",
//         surname: "Nurlankyzy",
//         age: "20",
//         group: "PK"
//     },

//     {
//         name: "Bektur",
//         surname: "Askarov",
//         age: "18",
//         group: "JK"
//     }
// ] 

// const appendStudent = (student) => {
//     listDiv.append(`
//     <div class = "studentBlock">
//     <p>Name: ${student.name}</p>
//     <p>Surname: ${student.surname}</p>
//     <p>Age: ${student.age}</p>
//     <p>Group: ${student.group}</p>
//     </div>
//     `)
// }







// data.map(item => appendStudent(item))

// let studentCards = document.querySelectorAll(".studentBlock")

// for(let i = 0; i < studentCards.length;  i++){
//     studentCards[i].addEventListener('click', function(event){
//         // console.log(event.currentTarget)
//         let card = event.currentTarget
//         console.log(card.childNodes[1].innerHTML)
//     })
// }












// ajax - zapros
// GET, POST, DELETE, UPDATE




let listDiv = $("#lists")

btn.addEventListener('click', function(){
    $.ajax({
    url: "https://randomuser.me/api/",
    method: "get",
    success: function (response) {
        let info = $("#lists")
        appendLists(response.results[0])
    },
    error: function (response) {
        console.log("error")
    }

})
})


const appendLists = (user) => {
    listDiv.append(`
    <div class = "user">
    Name: ${user.name.title} ${user.name.first} ${user.name.last}<br>
    Date of birth: ${user.dob.date}<br>
    Age: ${user.dob.age}<br>
    Address: ${user.location.street.number} ${user.location.street.name}<br>
    Location: ${user.location.city} ${user.location.state} ${user.location.country}<br>
    Phone: ${user.phone} and ${user.cell}<br>
    Email: ${user.email}<br>
    Registered: ${user.registered.date}<br><br>
    <img src = "${user.picture.large}" width = "100px">
    </div>
    <hr>
    `)
}


















